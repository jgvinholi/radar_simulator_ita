dbstop if error
obj = RadarSimulator;
simtime = 1; % seconds
obj.npulses_per_prediction = 10;
SCR = -100:20:0; % db
SNR = 100;
Pd_ncoh = zeros(length(SCR), 1);
Pd_coh = zeros(length(SCR), 1);
Pd_bin = zeros(length(SCR), 1);
Pd_none = zeros(length(SCR), 1);
pfa_ncoh = zeros(length(SCR), 1);
pfa_coh = zeros(length(SCR), 1);
pfa_bin = zeros(length(SCR), 1);
pfa_none = zeros(length(SCR), 1);



for i=1:length(SCR)
    obj = RadarSimulator;
    obj.K0 = 3.5;
    obj.dSNR = SNR;
    obj.dSCR = SCR(i)
%     obj.K0 = K0*sqrt(obj.npulses_per_prediction);
    obj.Integrator = 'noncoherent';
    obj = update_parameters(obj);
    result_struct_ncoh = runSim(obj, simtime);
    Pd_ncoh(i) = result_struct_ncoh.pd;
    pfa_ncoh(i) = result_struct_ncoh.pfa;
    
    obj.Integrator = 'coherent';
    obj = update_parameters(obj);
    result_struct_coh = runSim(obj, simtime);
    Pd_coh(i) = result_struct_coh.pd;
    pfa_coh(i) = result_struct_coh.pfa;
    
    
%     obj.K0 = K0;
    obj.Integrator = 'none';
    obj = update_parameters(obj);
    result_struct_none = runSim(obj, simtime);
    
    Pd_none(i) = result_struct_none.pd;
    pfa_none(i) = result_struct_none.pfa;
    
%     obj.Integrator = 'binary';
%     obj = update_parameters(obj);
%     result_struct_bin = runSim(obj, simtime);
%     Pd_bin(i) = result_struct_bin.pd;
end

figure
hold on;
grid on

% plot(SCR, Pd_bin)
plot(SCR, Pd_coh)
plot(SCR, Pd_ncoh)
plot(SCR, Pd_none)
xlabel('SCR [db]')
title('Pd')
legend('Coherent', 'Noncoherent', 'None')


figure
hold on;
grid on

% plot(SCR, pfa_bin)
plot(SCR, pfa_coh)
plot(SCR, pfa_ncoh)
plot(SCR, pfa_none)
xlabel('SCR [db]')
title('PFA')
legend('Coherent', 'Noncoherent', 'None')

